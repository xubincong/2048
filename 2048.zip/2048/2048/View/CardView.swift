//
//  CardView.swift
//  2048
//
//  Created by xubincong on 2018/10/19.
//  Copyright © 2018 xubincong. All rights reserved.
//

import UIKit

class CardView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
