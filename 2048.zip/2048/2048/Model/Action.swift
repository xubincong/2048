//
//  Action.swift
//  2048
//
//  Created by xubincong on 2018/10/19.
//  Copyright © 2018 xubincong. All rights reserved.
//

import Foundation

enum Action {
    case move(from: Position, to: Position)
    case upgrade(from: Position, to: Position, value: Int)
    case new(at: Position, value: Int)
    case success
    case failure
}
