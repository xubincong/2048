//
//  ViewController.swift
//  2048
//
//  Created by xubincong on 2018/10/19.
//  Copyright © 2018 xubincong. All rights reserved.
//

import UIKit

class ViewController: UIViewController,GameViewDelegate {
    
    private let size = 4
    private lazy var game = Game(size: size)
    
    @IBOutlet weak var gameView: GameView! {
        didSet {
            gameView.size = size
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        gameView.delegate = self
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(500)) {
            self.startGame()
        }
    }

    private func startGame() {
        self.game.start { (startCards) in
            self.gameView.performActions(startCards)
        }
    }
    
    
    //算出direction
    func slideEnded(offset: CGPoint) {
        let direction: Direction
        if offset.y > offset.x {
            if offset.y > -offset.x {
                direction = .down
        } else {
            direction = .left
        }
    } else {
        if offset.y > -offset.x {
            direction = .right
        } else {
            direction = .up
        }
    }
        
        //把direction传到game的move
        game.move(direction) { (actions) in
            gameView.performActions(actions)
        }
    }

}
